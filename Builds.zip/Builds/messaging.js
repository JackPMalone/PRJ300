// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAvROZ1we0Sb3FcFfN5uugalhMq4ml6H9k",
  authDomain: "prj300-4ab58.firebaseapp.com",
  projectId: "prj300-4ab58",
  storageBucket: "prj300-4ab58.appspot.com",
  messagingSenderId: "1088012635956",
  appId: "1:1088012635956:web:60f63e112a976cacdf9f61",
  measurementId: "G-19F7HN2W6N"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);